package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DatabaseActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_database);

        Button addButton = findViewById(R.id.addButton);
        EditText eventEditText = findViewById(R.id.eventEditText);
        EditText locationEditText = findViewById(R.id.locationEditText);
        EditText timeEditText = findViewById(R.id.timeEditText);
        TableLayout tableLayout = findViewById(R.id.tableLayout);

        Button sendMessageBtn = (Button)findViewById(R.id.sendMessage);

        sendMessageBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DatabaseActivity.this, SmsActivity.class));
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String event = eventEditText.getText().toString();
                String location = locationEditText.getText().toString();
                String time = timeEditText.getText().toString();

                TableRow tableRow = (TableRow) LayoutInflater.from(DatabaseActivity.this).inflate(R.layout.table_row, null);
                ((TextView) tableRow.findViewById(R.id.numberTextView)).setText(event);
                ((TextView) tableRow.findViewById(R.id.nameTextView)).setText(location);
                ((TextView) tableRow.findViewById(R.id.emailTextView)).setText(time);

                Button removeButton = tableRow.findViewById(R.id.removeButton);
                removeButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tableLayout.removeView(tableRow);
                    }
                });


                tableLayout.addView(tableRow);
            }
        });
    }


}